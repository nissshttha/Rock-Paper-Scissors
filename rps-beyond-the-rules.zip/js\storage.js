/**
 * Rock Paper Scissors — Beyond The Rules
 * Local Storage Persistence & State Management
 */

const STORAGE_KEY = 'rps_beyond_the_rules_save_v1';

const DEFAULT_STATE = {
  unlockedLevels: [1],
  completedLevels: [],
  levelStars: { 1: 0, 2: 0, 3: 0, 4: 0 },
  highScores: { 1: 0, 2: 0, 3: 0, 4: 0 },
  totalScore: 0,
  totalWins: 0,
  totalLosses: 0,
  totalTies: 0,
  highestStreak: 0,
  achievements: [],
  settings: {
    sound: true,
    reducedMotion: false,
    showShortcuts: true
  }
};

export const ACHIEVEMENTS_LIST = [
  {
    id: 'first_blood',
    title: 'First Step',
    description: 'Win your very first round of Rock Paper Scissors.',
    icon: '🌱'
  },
  {
    id: 'classic_master',
    title: 'Classic Champion',
    description: 'Clear Level 1 without losing more than one round.',
    icon: '🏅'
  },
  {
    id: 'cosmic_bender',
    title: 'Cosmic Bender',
    description: 'Triumph over Level 2 under shifting cosmic rules.',
    icon: '🌌'
  },
  {
    id: 'mind_reader',
    title: 'Mind Reader',
    description: 'Decode Aura’s sacred cycle and clear Level 3.',
    icon: '🔮'
  },
  {
    id: 'tactician',
    title: 'Tactical Genius',
    description: 'Successfully invoke a Tactical Power Card in Level 4.',
    icon: '⚡'
  },
  {
    id: 'grand_champion',
    title: 'Beyond The Rules',
    description: 'Defeat Aura in Level 4 and complete the entire journey.',
    icon: '👑'
  },
  {
    id: 'streak_3',
    title: 'On Fire',
    description: 'Achieve a winning streak of 3 consecutive rounds.',
    icon: '🔥'
  }
];

export class GameStorage {
  constructor() {
    this.state = this.load();
  }

  load() {
    try {
      const storageObj = typeof window !== 'undefined' && window.localStorage ? window.localStorage : (typeof globalThis !== 'undefined' ? globalThis.localStorage : null);
      if (!storageObj) return { ...DEFAULT_STATE };
      const data = storageObj.getItem(STORAGE_KEY);
      if (!data) return { ...DEFAULT_STATE };
      const parsed = JSON.parse(data);
      return {
        ...DEFAULT_STATE,
        ...parsed,
        levelStars: { ...DEFAULT_STATE.levelStars, ...(parsed.levelStars || {}) },
        highScores: { ...DEFAULT_STATE.highScores, ...(parsed.highScores || {}) },
        settings: { ...DEFAULT_STATE.settings, ...(parsed.settings || {}) }
      };
    } catch (e) {
      console.warn('Failed to load saved state from localStorage; using defaults', e);
      return { ...DEFAULT_STATE };
    }
  }

  save() {
    try {
      const storageObj = typeof window !== 'undefined' && window.localStorage ? window.localStorage : (typeof globalThis !== 'undefined' ? globalThis.localStorage : null);
      if (!storageObj) return;
      storageObj.setItem(STORAGE_KEY, JSON.stringify(this.state));
    } catch (e) {
      console.warn('Failed to save state to localStorage', e);
    }
  }

  getUnlockedLevels() {
    return this.state.unlockedLevels;
  }

  isLevelUnlocked(level) {
    return this.state.unlockedLevels.includes(level);
  }

  unlockLevel(level) {
    if (!this.state.unlockedLevels.includes(level)) {
      this.state.unlockedLevels.push(level);
      this.save();
    }
  }

  completeLevel(level, stars, score) {
    if (!this.state.completedLevels.includes(level)) {
      this.state.completedLevels.push(level);
    }
    // Update stars if higher
    if ((this.state.levelStars[level] || 0) < stars) {
      this.state.levelStars[level] = stars;
    }
    // Update high score if higher
    if ((this.state.highScores[level] || 0) < score) {
      this.state.highScores[level] = score;
    }
    // Unlock next level if level < 4
    if (level < 4) {
      this.unlockLevel(level + 1);
    }
    this.save();
  }

  updateStats(win, tie, streak, points = 0) {
    if (win) {
      this.state.totalWins++;
      this.unlockAchievement('first_blood');
    } else if (tie) {
      this.state.totalTies++;
    } else {
      this.state.totalLosses++;
    }

    if (streak > this.state.highestStreak) {
      this.state.highestStreak = streak;
    }
    if (streak >= 3) {
      this.unlockAchievement('streak_3');
    }

    this.state.totalScore += points;
    this.save();
  }

  unlockAchievement(id) {
    if (!this.state.achievements.includes(id)) {
      this.state.achievements.push(id);
      this.save();
      return true; // Newly unlocked
    }
    return false;
  }

  hasAchievement(id) {
    return this.state.achievements.includes(id);
  }

  getSetting(key) {
    return this.state.settings[key];
  }

  setSetting(key, value) {
    this.state.settings[key] = value;
    this.save();
  }

  resetAll() {
    this.state = {
      ...DEFAULT_STATE,
      settings: { ...this.state.settings } // preserve audio / motion preferences across game progress reset
    };
    this.save();
  }
}

export const storage = new GameStorage();
