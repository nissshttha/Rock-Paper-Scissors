/**
 * Automated Unit Test Suite for RPS: Beyond The Rules
 * Tests 100% of classic and modified game mechanics.
 */

import {
  CHOICES,
  OUTCOMES,
  MODIFIERS,
  POWERS,
  resolveRound,
  LEVELS_CONFIG
} from '../js/game-logic.js';

let passed = 0;
let failed = 0;

function assert(condition, testName) {
  if (condition) {
    passed++;
    console.log(`  ✓ ${testName}`);
  } else {
    failed++;
    console.error(`  ✗ FAIL: ${testName}`);
  }
}

function assertEquals(actual, expected, testName) {
  if (actual === expected) {
    passed++;
    console.log(`  ✓ ${testName}`);
  } else {
    failed++;
    console.error(`  ✗ FAIL: ${testName} — Expected: ${expected}, Got: ${actual}`);
  }
}

console.log('\n========================================');
console.log('--- 1. CLASSIC RULES (Level 1 Tests) ---');
console.log('========================================');

// Winning combinations
assertEquals(resolveRound(CHOICES.ROCK, CHOICES.SCISSORS).outcome, OUTCOMES.WIN, 'Rock beats Scissors');
assertEquals(resolveRound(CHOICES.SCISSORS, CHOICES.PAPER).outcome, OUTCOMES.WIN, 'Scissors beats Paper');
assertEquals(resolveRound(CHOICES.PAPER, CHOICES.ROCK).outcome, OUTCOMES.WIN, 'Paper beats Rock');

// Losing combinations
assertEquals(resolveRound(CHOICES.SCISSORS, CHOICES.ROCK).outcome, OUTCOMES.LOSE, 'Scissors loses to Rock');
assertEquals(resolveRound(CHOICES.PAPER, CHOICES.SCISSORS).outcome, OUTCOMES.LOSE, 'Paper loses to Scissors');
assertEquals(resolveRound(CHOICES.ROCK, CHOICES.PAPER).outcome, OUTCOMES.LOSE, 'Rock loses to Paper');

// Tie combinations
assertEquals(resolveRound(CHOICES.ROCK, CHOICES.ROCK).outcome, OUTCOMES.TIE, 'Rock ties with Rock');
assertEquals(resolveRound(CHOICES.PAPER, CHOICES.PAPER).outcome, OUTCOMES.TIE, 'Paper ties with Paper');
assertEquals(resolveRound(CHOICES.SCISSORS, CHOICES.SCISSORS).outcome, OUTCOMES.TIE, 'Scissors ties with Scissors');

// Points verification
const winRes = resolveRound(CHOICES.ROCK, CHOICES.SCISSORS);
assertEquals(winRes.playerPoints, 1, 'Standard win awards 1 point to player');
assertEquals(winRes.opponentPoints, 0, 'Standard win awards 0 points to opponent');

const loseRes = resolveRound(CHOICES.PAPER, CHOICES.SCISSORS);
assertEquals(loseRes.playerPoints, 0, 'Standard lose awards 0 points to player');
assertEquals(loseRes.opponentPoints, 1, 'Standard lose awards 1 point to opponent');

const tieRes = resolveRound(CHOICES.PAPER, CHOICES.PAPER);
assertEquals(tieRes.playerPoints, 0, 'Standard tie awards 0 points to player');
assertEquals(tieRes.opponentPoints, 0, 'Standard tie awards 0 points to opponent');

console.log('\n========================================');
console.log('--- 2. COSMIC INVERSION MODIFIER (Level 2 Tests) ---');
console.log('========================================');

// Under inversion: Paper beats Scissors, Scissors beats Rock, Rock beats Paper
assertEquals(
  resolveRound(CHOICES.ROCK, CHOICES.SCISSORS, MODIFIERS.INVERSION).outcome,
  OUTCOMES.LOSE,
  'Inversion: Rock loses to Scissors'
);
assertEquals(
  resolveRound(CHOICES.SCISSORS, CHOICES.PAPER, MODIFIERS.INVERSION).outcome,
  OUTCOMES.LOSE,
  'Inversion: Scissors loses to Paper'
);
assertEquals(
  resolveRound(CHOICES.PAPER, CHOICES.ROCK, MODIFIERS.INVERSION).outcome,
  OUTCOMES.LOSE,
  'Inversion: Paper loses to Rock'
);
assertEquals(
  resolveRound(CHOICES.SCISSORS, CHOICES.ROCK, MODIFIERS.INVERSION).outcome,
  OUTCOMES.WIN,
  'Inversion: Scissors beats Rock'
);
assertEquals(
  resolveRound(CHOICES.PAPER, CHOICES.SCISSORS, MODIFIERS.INVERSION).outcome,
  OUTCOMES.WIN,
  'Inversion: Paper beats Scissors'
);
assertEquals(
  resolveRound(CHOICES.ROCK, CHOICES.PAPER, MODIFIERS.INVERSION).outcome,
  OUTCOMES.WIN,
  'Inversion: Rock beats Paper'
);
assertEquals(
  resolveRound(CHOICES.ROCK, CHOICES.ROCK, MODIFIERS.INVERSION).outcome,
  OUTCOMES.TIE,
  'Inversion: Ties remain Ties'
);

console.log('\n========================================');
console.log('--- 3. GOLDEN SPARK MODIFIER (Level 2 Tests) ---');
console.log('========================================');

const goldenSparkTie = resolveRound(CHOICES.ROCK, CHOICES.ROCK, MODIFIERS.GOLDEN_SPARK);
assertEquals(goldenSparkTie.outcome, OUTCOMES.WIN, 'Golden Spark converts Tie to Player Victory');
assertEquals(goldenSparkTie.playerPoints, 1, 'Golden Spark awards 1 point to player on Tie');
assertEquals(
  resolveRound(CHOICES.SCISSORS, CHOICES.ROCK, MODIFIERS.GOLDEN_SPARK).outcome,
  OUTCOMES.LOSE,
  'Golden Spark does not convert a normal loss'
);

console.log('\n========================================');
console.log('--- 4. HEAVY OBSIDIAN MODIFIER (Level 2 Tests) ---');
console.log('========================================');

assertEquals(
  resolveRound(CHOICES.ROCK, CHOICES.PAPER, MODIFIERS.HEAVY_OBSIDIAN).outcome,
  OUTCOMES.TIE,
  'Heavy Obsidian: Rock vs Paper resolves as a Tie instead of Lose'
);
assertEquals(
  resolveRound(CHOICES.PAPER, CHOICES.ROCK, MODIFIERS.HEAVY_OBSIDIAN).outcome,
  OUTCOMES.TIE,
  'Heavy Obsidian: Opponent Rock vs Player Paper resolves as a Tie'
);
assertEquals(
  resolveRound(CHOICES.ROCK, CHOICES.SCISSORS, MODIFIERS.HEAVY_OBSIDIAN).outcome,
  OUTCOMES.WIN,
  'Heavy Obsidian: Rock still beats Scissors'
);
assertEquals(
  resolveRound(CHOICES.SCISSORS, CHOICES.PAPER, MODIFIERS.HEAVY_OBSIDIAN).outcome,
  OUTCOMES.WIN,
  'Heavy Obsidian: Scissors still cuts Paper'
);

console.log('\n========================================');
console.log('--- 5. BANNED ELEMENT MODIFIER (Level 2 Tests) ---');
console.log('========================================');

const bannedPlayerLoss = resolveRound(CHOICES.PAPER, CHOICES.ROCK, MODIFIERS.BANNED_PAPER);
assertEquals(bannedPlayerLoss.outcome, OUTCOMES.LOSE, 'Playing Banned Paper results in auto-loss');
assertEquals(bannedPlayerLoss.opponentPoints, 1, 'Opponent gains point when player plays banned move');

const bannedOpponentLoss = resolveRound(CHOICES.ROCK, CHOICES.PAPER, MODIFIERS.BANNED_PAPER);
assertEquals(bannedOpponentLoss.outcome, OUTCOMES.WIN, 'Opponent playing Banned Paper results in player win');
assertEquals(bannedOpponentLoss.playerPoints, 1, 'Player gains point when opponent plays banned move');

console.log('\n========================================');
console.log('--- 6. DOUBLE STAKES MODIFIER (Level 2 Tests) ---');
console.log('========================================');

const doubleWin = resolveRound(CHOICES.ROCK, CHOICES.SCISSORS, MODIFIERS.DOUBLE_STAKES);
assertEquals(doubleWin.playerPoints, 2, 'Double Stakes awards 2 points to winner');
const doubleLose = resolveRound(CHOICES.SCISSORS, CHOICES.ROCK, MODIFIERS.DOUBLE_STAKES);
assertEquals(doubleLose.opponentPoints, 2, 'Double Stakes awards 2 points to opponent on loss');

console.log('\n========================================');
console.log('--- 7. TACTICAL POWERS (Level 4 Tests) ---');
console.log('========================================');

// Aegis Shield
const shieldRes = resolveRound(CHOICES.ROCK, CHOICES.PAPER, MODIFIERS.NONE, POWERS.AEGIS_SHIELD);
assertEquals(shieldRes.outcome, OUTCOMES.TIE, 'Aegis Shield converts defeat into Tie');
assertEquals(shieldRes.opponentPoints, 0, 'Opponent gets 0 points when shield blocks');

// Rule Inverter
const inverterRes = resolveRound(CHOICES.SCISSORS, CHOICES.ROCK, MODIFIERS.NONE, POWERS.RULE_INVERTER);
assertEquals(inverterRes.outcome, OUTCOMES.WIN, 'Rule Inverter turns defeat into Victory');
assertEquals(inverterRes.playerPoints, 1, 'Player gets 1 point from inverted victory');

// Critical Surge
const surgeRes = resolveRound(CHOICES.PAPER, CHOICES.ROCK, MODIFIERS.NONE, POWERS.CRITICAL_SURGE);
assertEquals(surgeRes.outcome, OUTCOMES.WIN, 'Critical Surge maintains win');
assertEquals(surgeRes.playerPoints, 2, 'Critical Surge doubles player score on win');

console.log('\n========================================');
console.log('--- 8. LEVEL CONFIGURATION INTEGRITY ---');
console.log('========================================');

assertEquals(LEVELS_CONFIG.length, 4, 'Exactly 4 distinct levels configured');
assertEquals(LEVELS_CONFIG[0].targetWins, 3, 'Level 1 requires 3 target wins');
assertEquals(LEVELS_CONFIG[1].targetWins, 3, 'Level 2 requires 3 target wins');
assertEquals(LEVELS_CONFIG[2].hasPatternIntel, true, 'Level 3 enables pattern telemetry');
assertEquals(LEVELS_CONFIG[3].hasTacticalPowers, true, 'Level 4 enables tactical power cards');

console.log('\n========================================');
console.log(`TEST SUMMARY: ${passed} Passed, ${failed} Failed`);
console.log('========================================\n');

if (failed > 0) {
  process.exit(1);
} else {
  console.log('All Unit Tests Passed Successfully! ✨');
}
