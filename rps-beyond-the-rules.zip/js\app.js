/**
 * Rock Paper Scissors — Beyond The Rules
 * Main Game Coordinator & Application State
 */

import { CHOICES, OUTCOMES, MODIFIERS, POWERS, LEVELS_CONFIG, resolveRound } from './game-logic.js';
import { OpponentAI, AURA_MOODS } from './opponent-ai.js';
import { sounds } from './audio.js';
import { storage } from './storage.js';
import { UIManager, ICONS } from './ui.js';

class RPSGameApp {
  constructor() {
    this.ui = new UIManager();
    this.opponent = new OpponentAI();

    // Game Session State
    this.currentLevel = 1;
    this.roundIndex = 1;
    this.playerWins = 0;
    this.opponentWins = 0;
    this.currentStreak = 0;
    this.totalMatchScore = 0;
    this.inputLocked = false;

    // Active Modifiers and Powers
    this.activeModifier = MODIFIERS.NONE;
    this.level2ModifierIndex = 0;
    this.activePower = POWERS.NONE;
    this.powersState = [];

    this.init();
  }

  init() {
    this.initSettings();
    this.bindEvents();
    this.showWelcome();
  }

  initSettings() {
    const isMuted = !storage.getSetting('sound');
    sounds.setMuted(isMuted);
    this.updateSoundBtnIcon();

    if (storage.getSetting('reducedMotion')) {
      document.body.classList.add('reduced-motion');
    }
  }

  updateSoundBtnIcon() {
    const btn = document.getElementById('btn-sound-toggle');
    if (!btn) return;
    const muted = sounds.isMuted();
    btn.innerHTML = muted ? '🔇' : '🔊';
    btn.setAttribute('aria-label', muted ? 'Unmute Sound' : 'Mute Sound');
    btn.setAttribute('title', muted ? 'Unmute Sound' : 'Mute Sound');
  }

  bindEvents() {
    // Top Bar Navigation
    const soundBtn = document.getElementById('btn-sound-toggle');
    if (soundBtn) {
      soundBtn.addEventListener('click', () => {
        const nextMuted = !sounds.isMuted();
        sounds.setMuted(nextMuted);
        storage.setSetting('sound', !nextMuted);
        this.updateSoundBtnIcon();
        if (!nextMuted) sounds.playHover();
      });
    }

    const helpBtn = document.getElementById('btn-help');
    if (helpBtn) {
      helpBtn.addEventListener('click', () => {
        sounds.playSelect();
        this.openModal('modal-instructions');
      });
    }

    const settingsBtn = document.getElementById('btn-settings');
    if (settingsBtn) {
      settingsBtn.addEventListener('click', () => {
        sounds.playSelect();
        this.openModal('modal-settings');
      });
    }

    const mapNavBtn = document.getElementById('btn-nav-map');
    if (mapNavBtn) {
      mapNavBtn.addEventListener('click', () => {
        sounds.playSelect();
        this.showLevelMap();
      });
    }

    const homeNavBtn = document.getElementById('btn-nav-home');
    if (homeNavBtn) {
      homeNavBtn.addEventListener('click', () => {
        sounds.playSelect();
        this.showWelcome();
      });
    }

    // Welcome Screen Buttons
    const startBtn = document.getElementById('btn-start-game');
    if (startBtn) {
      startBtn.addEventListener('click', () => {
        sounds.playSelect();
        this.startLevel(1);
      });
    }

    const mapBtn = document.getElementById('btn-view-map');
    if (mapBtn) {
      mapBtn.addEventListener('click', () => {
        sounds.playSelect();
        this.showLevelMap();
      });
    }

    const rulesBtn = document.getElementById('btn-view-rules');
    if (rulesBtn) {
      rulesBtn.addEventListener('click', () => {
        sounds.playSelect();
        this.openModal('modal-instructions');
      });
    }

    // Modal Close Buttons
    document.querySelectorAll('.modal-close-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        sounds.playHover();
        const modal = btn.closest('.modal-overlay');
        if (modal) modal.classList.remove('active');
      });
    });

    // Close modal on background click
    document.querySelectorAll('.modal-overlay').forEach(modal => {
      modal.addEventListener('click', (e) => {
        if (e.target === modal) {
          sounds.playHover();
          modal.classList.remove('active');
        }
      });
    });

    // Guide Modal Tabs
    document.querySelectorAll('.guide-tab-btn').forEach(tabBtn => {
      tabBtn.addEventListener('click', () => {
        sounds.playHover();
        const tabId = tabBtn.getAttribute('data-tab');
        document.querySelectorAll('.guide-tab-btn').forEach(b => b.classList.remove('active'));
        document.querySelectorAll('.guide-content-panel').forEach(p => p.classList.remove('active'));

        tabBtn.classList.add('active');
        const panel = document.getElementById(`tab-panel-${tabId}`);
        if (panel) panel.classList.add('active');
      });
    });

    // Settings Modal Options
    const optSound = document.getElementById('opt-sound');
    if (optSound) {
      optSound.checked = storage.getSetting('sound');
      optSound.addEventListener('change', (e) => {
        sounds.setMuted(!e.target.checked);
        storage.setSetting('sound', e.target.checked);
        this.updateSoundBtnIcon();
      });
    }

    const optMotion = document.getElementById('opt-reduced-motion');
    if (optMotion) {
      optMotion.checked = storage.getSetting('reducedMotion');
      optMotion.addEventListener('change', (e) => {
        storage.setSetting('reducedMotion', e.target.checked);
        if (e.target.checked) {
          document.body.classList.add('reduced-motion');
        } else {
          document.body.classList.remove('reduced-motion');
        }
      });
    }

    const resetBtn = document.getElementById('btn-reset-progress');
    if (resetBtn) {
      resetBtn.addEventListener('click', () => {
        if (confirm('Are you sure you want to reset all unlocked levels and high scores? This cannot be undone.')) {
          storage.resetAll();
          sounds.playSelect();
          alert('Game progress has been reset.');
          this.showWelcome();
          const modal = document.getElementById('modal-settings');
          if (modal) modal.classList.remove('active');
        }
      });
    }

    // Gameplay Choice Buttons
    document.querySelectorAll('.choice-btn').forEach(btn => {
      btn.addEventListener('mouseenter', () => sounds.playHover());
      btn.addEventListener('click', () => {
        const choice = btn.getAttribute('data-choice');
        this.handlePlayerChoice(choice);
      });
    });

    // Keyboard Shortcuts (R, P, S, 1, 2, 3, Space, Esc)
    window.addEventListener('keydown', (e) => {
      // Ignore if user is inside an input or select
      if (['INPUT', 'SELECT', 'TEXTAREA'].includes(e.target.tagName)) return;

      const key = e.key.toUpperCase();

      if (key === 'ESCAPE') {
        const activeModal = document.querySelector('.modal-overlay.active');
        if (activeModal) {
          activeModal.classList.remove('active');
          sounds.playHover();
        }
        return;
      }

      // If on gameplay screen and not locked
      const gameplayScreen = document.getElementById('screen-gameplay');
      if (gameplayScreen && gameplayScreen.classList.contains('active') && !this.inputLocked) {
        if (key === 'R' || key === '1') {
          e.preventDefault();
          this.handlePlayerChoice(CHOICES.ROCK);
        } else if (key === 'P' || key === '2') {
          e.preventDefault();
          this.handlePlayerChoice(CHOICES.PAPER);
        } else if (key === 'S' || key === '3') {
          e.preventDefault();
          this.handlePlayerChoice(CHOICES.SCISSORS);
        }
      }
    });
  }

  openModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) modal.classList.add('active');
  }

  showWelcome() {
    this.ui.showScreen('screen-welcome');
  }

  showLevelMap() {
    this.ui.renderLevelGrid((lvl) => this.startLevel(lvl));
    this.ui.showScreen('screen-levels');
  }

  /**
   * Start a given level (1 - 4)
   */
  startLevel(levelNumber) {
    const config = LEVELS_CONFIG.find(c => c.level === levelNumber) || LEVELS_CONFIG[0];
    this.currentLevel = levelNumber;
    this.roundIndex = 1;
    this.playerWins = 0;
    this.opponentWins = 0;
    this.currentStreak = 0;
    this.totalMatchScore = 0;
    this.inputLocked = false;
    this.level2ModifierIndex = 0;
    this.activePower = POWERS.NONE;

    // Reset Opponent AI
    this.opponent.reset(levelNumber);

    // Initialize Level Modifiers
    if (levelNumber === 2) {
      this.activeModifier = config.availableModifiers[0];
    } else {
      this.activeModifier = MODIFIERS.NONE;
    }

    // Initialize Level 4 Powers
    if (levelNumber === 4) {
      this.powersState = [
        { id: POWERS.AEGIS_SHIELD, name: 'Aegis Shield', count: 1, desc: 'Turns defeat into a Tie', selected: false },
        { id: POWERS.RULE_INVERTER, name: 'Rule Inverter', count: 1, desc: 'Twists defeat into Victory', selected: false },
        { id: POWERS.CRITICAL_SURGE, name: 'Critical Surge', count: 1, desc: 'Earns 2 points on a Win', selected: false }
      ];
    } else {
      this.powersState = [];
    }

    // Refresh UI Components
    this.ui.resetClashDisplay();
    this.ui.updateHUD(config, this.playerWins, this.opponentWins, this.roundIndex, this.currentStreak);
    this.ui.updateAura(AURA_MOODS.IDLE, this.opponent.getDialogue('start', levelNumber));
    this.ui.updateModifierBanner(this.activeModifier, levelNumber);
    this.ui.updatePatternTelemetry(levelNumber, this.opponent.history, this.opponent.level3StepIndex);
    this.ui.updateTacticalDock(levelNumber, this.powersState, (powerId) => this.togglePower(powerId));

    // Enable Choice Buttons
    this.setChoiceButtonsDisabled(false);

    // Switch to gameplay screen
    this.ui.showScreen('screen-gameplay');
  }

  togglePower(powerId) {
    if (this.inputLocked) return;
    const power = this.powersState.find(p => p.id === powerId);
    if (!power || power.count <= 0) return;

    if (this.activePower === powerId) {
      // Deselect
      this.activePower = POWERS.NONE;
      power.selected = false;
    } else {
      // Select
      this.powersState.forEach(p => (p.selected = false));
      power.selected = true;
      this.activePower = powerId;
      sounds.playPower();
    }

    this.ui.updateTacticalDock(this.currentLevel, this.powersState, (id) => this.togglePower(id));
  }

  setChoiceButtonsDisabled(disabled) {
    document.querySelectorAll('.choice-btn').forEach(btn => {
      btn.disabled = disabled;
    });
  }

  /**
   * Handle Player Move Selection
   */
  handlePlayerChoice(playerChoice) {
    if (this.inputLocked) return;
    this.inputLocked = true;
    this.setChoiceButtonsDisabled(true);

    sounds.playSelect();

    // Visual selection feedback
    document.querySelectorAll('.choice-btn').forEach(btn => {
      if (btn.getAttribute('data-choice') === playerChoice) {
        btn.classList.add('selected');
        setTimeout(() => btn.classList.remove('selected'), 350);
      }
    });

    // Opponent makes decision
    const auraChoice = this.opponent.decideMove(this.currentLevel, this.activeModifier);

    // Deterministic resolution
    const result = resolveRound(playerChoice, auraChoice, this.activeModifier, this.activePower);

    // If power was used, deduct charge
    if (this.activePower !== POWERS.NONE) {
      const p = this.powersState.find(x => x.id === this.activePower);
      if (p && p.count > 0) {
        p.count--;
        p.selected = false;
      }
      this.activePower = POWERS.NONE;
    }

    // Update Opponent Record
    this.opponent.recordRound(auraChoice, playerChoice);

    // Update Scores & Moods
    let auraMood = AURA_MOODS.IDLE;
    if (result.outcome === OUTCOMES.WIN) {
      this.playerWins += result.playerPoints;
      this.currentStreak++;
      this.totalMatchScore += result.playerPoints * 100 + this.currentStreak * 20;
      auraMood = AURA_MOODS.PUZZLED;
      sounds.playWin();
    } else if (result.outcome === OUTCOMES.LOSE) {
      this.opponentWins += result.opponentPoints;
      this.currentStreak = 0;
      auraMood = AURA_MOODS.HAPPY;
      sounds.playLose();
    } else {
      auraMood = AURA_MOODS.TIE;
      sounds.playTie();
    }

    // Save persistent stats
    storage.updateStats(
      result.outcome === OUTCOMES.WIN,
      result.outcome === OUTCOMES.TIE,
      this.currentStreak,
      result.playerPoints * 100
    );

    // Update Aura Mascot Dialogue
    const dialogue = this.opponent.getDialogue(
      result.outcome,
      this.currentLevel,
      this.activeModifier,
      result.powerApplied
    );
    this.ui.updateAura(auraMood, dialogue);

    // Clash Display Animation
    this.ui.showClash(playerChoice, auraChoice, result, () => {
      const config = LEVELS_CONFIG.find(c => c.level === this.currentLevel);

      // Check Victory Condition
      if (this.playerWins >= config.targetWins) {
        let stars = 1;
        if (this.opponentWins === 0) stars = 3;
        else if (this.opponentWins <= 1) stars = 2;

        storage.completeLevel(this.currentLevel, stars, this.totalMatchScore);

        if (this.currentLevel >= 4) {
          storage.unlockAchievement('grand_champion');
          this.ui.showFinalVictoryModal(
            this.totalMatchScore,
            () => this.startLevel(1),
            () => this.showLevelMap()
          );
        } else {
          this.ui.showLevelCompleteModal(
            this.currentLevel,
            stars,
            this.totalMatchScore,
            () => this.startLevel(this.currentLevel + 1),
            () => this.showLevelMap()
          );
        }
        return;
      }

      // Check Failure Condition
      if (this.opponentWins >= config.targetWins || this.roundIndex >= config.maxRounds) {
        this.ui.showLevelFailedModal(
          this.currentLevel,
          this.playerWins,
          this.opponentWins,
          () => this.startLevel(this.currentLevel),
          () => this.showLevelMap()
        );
        return;
      }

      // Advance to Next Round after brief pause
      setTimeout(() => {
        this.advanceRound();
      }, 900);
    });
  }

  advanceRound() {
    this.roundIndex++;
    const config = LEVELS_CONFIG.find(c => c.level === this.currentLevel);

    // In Level 2, shift modifier deterministically each round
    if (this.currentLevel === 2) {
      this.level2ModifierIndex = (this.level2ModifierIndex + 1) % config.availableModifiers.length;
      this.activeModifier = config.availableModifiers[this.level2ModifierIndex];
    }

    // Refresh UI Displays
    this.ui.resetClashDisplay();
    this.ui.updateHUD(config, this.playerWins, this.opponentWins, this.roundIndex, this.currentStreak);
    this.ui.updateModifierBanner(this.activeModifier, this.currentLevel);
    this.ui.updatePatternTelemetry(this.currentLevel, this.opponent.history, this.opponent.level3StepIndex);
    this.ui.updateTacticalDock(this.currentLevel, this.powersState, (id) => this.togglePower(id));

    this.inputLocked = false;
    this.setChoiceButtonsDisabled(false);
  }
}

// Instantiate and start app on DOM content loaded
window.addEventListener('DOMContentLoaded', () => {
  window.rpsApp = new RPSGameApp();
});
