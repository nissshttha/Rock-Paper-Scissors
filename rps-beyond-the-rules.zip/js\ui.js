/**
 * Rock Paper Scissors — Beyond The Rules
 * UI View Controller, Animations, SVG Graphics & Screen Management
 */

import { CHOICES, OUTCOMES, MODIFIERS, POWERS, LEVELS_CONFIG } from './game-logic.js';
import { AURA_MOODS } from './opponent-ai.js';
import { sounds } from './audio.js';
import { storage, ACHIEVEMENTS_LIST } from './storage.js';

/* SVG Icons for Choices and Mascot */
export const ICONS = {
  rock: `<svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M12 28L18 14C19 12 22 10 25 10L32 14C35 16 37 19 36 23L34 32C33 36 29 39 25 39H19C15 39 11 35 11 31L12 28Z" fill="#D6ECFB" stroke="#151D33" stroke-width="2.5" stroke-linejoin="round"/>
    <path d="M18 14L24 24L34 20" stroke="#151D33" stroke-width="2" stroke-linecap="round"/>
    <path d="M24 24L22 38" stroke="#151D33" stroke-width="2" stroke-linecap="round"/>
    <circle cx="20" cy="20" r="1.5" fill="#151D33"/>
    <circle cx="28" cy="28" r="1.5" fill="#151D33"/>
  </svg>`,

  paper: `<svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
    <rect x="12" y="10" width="24" height="30" rx="4" fill="#FEF4BD" stroke="#151D33" stroke-width="2.5"/>
    <line x1="17" y1="18" x2="31" y2="18" stroke="#151D33" stroke-width="2" stroke-linecap="round"/>
    <line x1="17" y1="24" x2="31" y2="24" stroke="#151D33" stroke-width="2" stroke-linecap="round"/>
    <line x1="17" y1="30" x2="26" y2="30" stroke="#151D33" stroke-width="2" stroke-linecap="round"/>
    <path d="M28 10V16H36" fill="#FDE887" stroke="#151D33" stroke-width="2"/>
  </svg>`,

  scissors: `<svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
    <circle cx="17" cy="33" r="5" fill="#F4E7FA" stroke="#151D33" stroke-width="2.5"/>
    <circle cx="31" cy="33" r="5" fill="#F4E7FA" stroke="#151D33" stroke-width="2.5"/>
    <path d="M20 29L34 13" stroke="#151D33" stroke-width="2.5" stroke-linecap="round"/>
    <path d="M28 29L14 13" stroke="#151D33" stroke-width="2.5" stroke-linecap="round"/>
    <circle cx="24" cy="23" r="2.5" fill="#151D33"/>
  </svg>`,

  shield: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>`,
  inverter: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="17 1 21 5 17 9"></polyline><path d="M3 11V9a4 4 0 0 1 4-4h14"></path><polyline points="7 23 3 19 7 15"></polyline><path d="M21 13v2a4 4 0 0 1-4 4H3"></path></svg>`,
  surge: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"></polygon></svg>`
};

/* Mascot Aura SVG Generator based on mood */
export function getAuraSVG(mood = AURA_MOODS.IDLE) {
  let eyeLeft = `<circle cx="38" cy="45" r="3.5" fill="#151D33"/>`;
  let eyeRight = `<circle cx="62" cy="45" r="3.5" fill="#151D33"/>`;
  let mouth = `<path d="M46 54 Q50 58 54 54" stroke="#151D33" stroke-width="2" fill="none" stroke-linecap="round"/>`;
  let blush = `<circle cx="34" cy="52" r="4" fill="#F9C7B2" opacity="0.6"/>
               <circle cx="66" cy="52" r="4" fill="#F9C7B2" opacity="0.6"/>`;
  let haloGlow = `#FEF4BD`;

  if (mood === AURA_MOODS.HAPPY || mood === AURA_MOODS.CELEBRATING) {
    eyeLeft = `<path d="M35 45 Q38 41 41 45" stroke="#151D33" stroke-width="2.5" fill="none" stroke-linecap="round"/>`;
    eyeRight = `<path d="M59 45 Q62 41 65 45" stroke="#151D33" stroke-width="2.5" fill="none" stroke-linecap="round"/>`;
    mouth = `<path d="M44 53 Q50 62 56 53 Z" fill="#F9C7B2" stroke="#151D33" stroke-width="2"/>`;
    haloGlow = `#D6F6E4`;
  } else if (mood === AURA_MOODS.PUZZLED) {
    eyeLeft = `<circle cx="38" cy="43" r="3.5" fill="#151D33"/>`;
    eyeRight = `<circle cx="62" cy="47" r="4" fill="#151D33"/>`;
    mouth = `<path d="M46 56 Q50 53 54 56" stroke="#151D33" stroke-width="2" fill="none" stroke-linecap="round"/>`;
    haloGlow = `#DFC2F2`;
  } else if (mood === AURA_MOODS.SHOCKED) {
    eyeLeft = `<circle cx="38" cy="44" r="5" fill="#151D33"/><circle cx="39" cy="43" r="1.5" fill="#FFF"/>`;
    eyeRight = `<circle cx="62" cy="44" r="5" fill="#151D33"/><circle cx="63" cy="43" r="1.5" fill="#FFF"/>`;
    mouth = `<circle cx="50" cy="55" r="3.5" fill="#151D33"/>`;
    haloGlow = `#FDE887`;
  } else if (mood === AURA_MOODS.DEFEATED) {
    eyeLeft = `<path d="M35 43 L41 47 M41 43 L35 47" stroke="#151D33" stroke-width="2" stroke-linecap="round"/>`;
    eyeRight = `<path d="M59 43 L65 47 M65 43 L59 47" stroke="#151D33" stroke-width="2" stroke-linecap="round"/>`;
    mouth = `<path d="M46 56 Q50 52 54 56" stroke="#151D33" stroke-width="2" fill="none" stroke-linecap="round"/>`;
    haloGlow = `#E4DCF9`;
  }

  return `
    <svg viewBox="0 0 100 100" class="opponent-avatar-svg" xmlns="http://www.w3.org/2000/svg">
      <!-- Floating Celestial Halo -->
      <ellipse cx="50" cy="22" rx="30" ry="8" fill="none" stroke="${haloGlow}" stroke-width="5" opacity="0.8"/>
      <ellipse cx="50" cy="22" rx="30" ry="8" fill="none" stroke="#151D33" stroke-width="2.5"/>
      
      <!-- Aura Spirit Body -->
      <path d="M24 60 C20 40 32 26 50 26 C68 26 80 40 76 60 C74 76 64 86 50 86 C36 86 26 76 24 60 Z" 
            fill="#E4DCF9" stroke="#151D33" stroke-width="2.5"/>
      
      <!-- Belly Soft Patch -->
      <path d="M35 62 C34 50 42 42 50 42 C58 42 66 50 65 62 C64 74 58 78 50 78 C42 78 36 74 35 62 Z" 
            fill="#F4E7FA" opacity="0.75"/>
      
      ${blush}
      ${eyeLeft}
      ${eyeRight}
      ${mouth}

      <!-- Tiny Floating Stars -->
      <circle cx="18" cy="40" r="2" fill="#FDE887" stroke="#151D33" stroke-width="1"/>
      <circle cx="82" cy="38" r="2.5" fill="#D6F6E4" stroke="#151D33" stroke-width="1"/>
      <circle cx="78" cy="68" r="1.8" fill="#FEF4BD" stroke="#151D33" stroke-width="1"/>
    </svg>
  `;
}

/* Confetti Particle Engine */
class ConfettiEngine {
  constructor(canvasId) {
    this.canvas = document.getElementById(canvasId);
    this.ctx = this.canvas ? this.canvas.getContext('2d') : null;
    this.particles = [];
    this.animating = false;
    this.pastelColors = ['#E4DCF9', '#F4E7FA', '#D6ECFB', '#D6F6E4', '#FEF4BD', '#FDE5D8', '#F9C7B2'];
    
    if (this.canvas) {
      this.resize();
      window.addEventListener('resize', () => this.resize());
    }
  }

  resize() {
    if (!this.canvas) return;
    this.canvas.width = window.innerWidth;
    this.canvas.height = window.innerHeight;
  }

  burst(count = 70) {
    if (!this.canvas || !this.ctx || storage.getSetting('reducedMotion')) return;
    this.resize();
    for (let i = 0; i < count; i++) {
      this.particles.push({
        x: this.canvas.width / 2 + (Math.random() - 0.5) * 200,
        y: this.canvas.height / 2 + (Math.random() - 0.5) * 100,
        vx: (Math.random() - 0.5) * 12,
        vy: Math.random() * -12 - 4,
        size: Math.random() * 8 + 5,
        color: this.pastelColors[Math.floor(Math.random() * this.pastelColors.length)],
        rotation: Math.random() * 360,
        vRot: (Math.random() - 0.5) * 10,
        life: 1,
        decay: Math.random() * 0.015 + 0.008
      });
    }

    if (!this.animating) {
      this.animating = true;
      this.render();
    }
  }

  render() {
    if (!this.ctx || !this.animating) return;
    this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);

    for (let i = this.particles.length - 1; i >= 0; i--) {
      const p = this.particles[i];
      p.x += p.vx;
      p.y += p.vy;
      p.vy += 0.35; // gravity
      p.rotation += p.vRot;
      p.life -= p.decay;

      if (p.life <= 0) {
        this.particles.splice(i, 1);
        continue;
      }

      this.ctx.save();
      this.ctx.translate(p.x, p.y);
      this.ctx.rotate((p.rotation * Math.PI) / 180);
      this.ctx.globalAlpha = p.life;
      this.ctx.fillStyle = p.color;
      this.ctx.strokeStyle = '#151D33';
      this.ctx.lineWidth = 1;
      this.ctx.fillRect(-p.size / 2, -p.size / 2, p.size, p.size);
      this.ctx.strokeRect(-p.size / 2, -p.size / 2, p.size, p.size);
      this.ctx.restore();
    }

    if (this.particles.length > 0) {
      requestAnimationFrame(() => this.render());
    } else {
      this.animating = false;
      this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
    }
  }
}

export class UIManager {
  constructor() {
    this.confetti = new ConfettiEngine('confetti-canvas');
  }

  /**
   * Switch active screen smoothly
   */
  showScreen(screenId) {
    document.querySelectorAll('.game-screen').forEach(s => s.classList.remove('active'));
    const target = document.getElementById(screenId);
    if (target) {
      target.classList.add('active');
    }
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  /**
   * Render Level Progression Cards on the Level Select screen
   */
  renderLevelGrid(onSelectLevel) {
    const grid = document.getElementById('levels-grid');
    if (!grid) return;
    grid.innerHTML = '';

    const unlocked = storage.getUnlockedLevels();
    const stars = storage.state.levelStars;
    const highScores = storage.state.highScores;

    LEVELS_CONFIG.forEach(cfg => {
      const isUnlocked = unlocked.includes(cfg.level);
      const isCompleted = storage.state.completedLevels.includes(cfg.level);
      const starCount = stars[cfg.level] || 0;
      const score = highScores[cfg.level] || 0;

      const card = document.createElement('div');
      card.className = `level-card ${isUnlocked ? '' : 'locked'}`;
      card.setAttribute('role', 'button');
      card.setAttribute('tabindex', isUnlocked ? '0' : '-1');
      card.setAttribute('aria-label', `${cfg.title}. ${isUnlocked ? 'Unlocked' : 'Locked'}`);

      let starsHtml = '';
      for (let s = 1; s <= 3; s++) {
        starsHtml += `<span class="${s <= starCount ? 'star-filled' : ''}">★</span>`;
      }

      card.innerHTML = `
        <div class="level-card-top">
          <span class="level-number-pill">Level 0${cfg.level}</span>
          <span class="level-status-pill">
            ${isUnlocked ? (isCompleted ? '✓ Cleared' : '● Unlocked') : '🔒 Locked'}
          </span>
        </div>
        <h3 class="level-card-title">${cfg.title.split(': ')[1] || cfg.title}</h3>
        <p class="level-card-sub">${cfg.description}</p>
        <div class="level-card-stars" aria-label="${starCount} of 3 stars">${starsHtml}</div>
        <div class="level-card-footer">
          <span>Target: ${cfg.targetWins} Wins</span>
          <span>Best: ${score} pts</span>
        </div>
      `;

      if (isUnlocked) {
        card.addEventListener('click', () => {
          sounds.playSelect();
          onSelectLevel(cfg.level);
        });
        card.addEventListener('keydown', (e) => {
          if (e.key === 'Enter' || e.key === ' ') {
            e.preventDefault();
            sounds.playSelect();
            onSelectLevel(cfg.level);
          }
        });
      }

      grid.appendChild(card);
    });
  }

  /**
   * Update active HUD elements (objective, scores, streak, round)
   */
  updateHUD(levelConfig, playerScore, opponentScore, roundIndex, streak) {
    const badge = document.getElementById('hud-level-badge');
    const obj = document.getElementById('hud-objective-text');
    const pScoreEl = document.getElementById('hud-player-score');
    const aScoreEl = document.getElementById('hud-aura-score');
    const streakEl = document.getElementById('hud-streak-count');
    const roundEl = document.getElementById('hud-round-text');

    if (badge) badge.textContent = `Lvl 0${levelConfig.level}`;
    if (obj) obj.innerHTML = `Objective: First to <strong>${levelConfig.targetWins} Wins</strong>`;
    if (pScoreEl) pScoreEl.textContent = playerScore;
    if (aScoreEl) aScoreEl.textContent = opponentScore;
    if (streakEl) streakEl.textContent = `${streak} 🔥`;
    if (roundEl) roundEl.textContent = `Round ${roundIndex}`;
  }

  /**
   * Update Aura's visual appearance and dialogue
   */
  updateAura(mood, speechText) {
    const avatarWrap = document.getElementById('opponent-avatar-wrap');
    const speechEl = document.getElementById('opponent-speech');

    if (avatarWrap) {
      avatarWrap.innerHTML = getAuraSVG(mood);
    }
    if (speechEl && speechText) {
      speechEl.textContent = speechText;
    }
  }

  /**
   * Configure Modifier Banner for Level 2 & others
   */
  updateModifierBanner(modifier, level) {
    const banner = document.getElementById('modifier-banner');
    const iconEl = document.getElementById('modifier-icon');
    const titleEl = document.getElementById('modifier-title');
    const descEl = document.getElementById('modifier-desc');

    if (!banner || !iconEl || !titleEl || !descEl) return;

    if (level === 2 && modifier !== MODIFIERS.NONE) {
      banner.style.display = 'flex';
      const info = this.getModifierDetails(modifier);
      iconEl.innerHTML = info.icon;
      titleEl.innerHTML = `${info.title} <span class="modifier-tag">Cosmic Rule</span>`;
      descEl.textContent = info.desc;
    } else {
      banner.style.display = 'none';
    }
  }

  getModifierDetails(modifier) {
    switch (modifier) {
      case MODIFIERS.INVERSION:
        return {
          icon: '🔄',
          title: 'Cosmic Inversion',
          desc: 'Rules are completely inverted! Paper beats Scissors, Scissors beats Rock, Rock beats Paper!'
        };
      case MODIFIERS.GOLDEN_SPARK:
        return {
          icon: '✨',
          title: 'Golden Spark',
          desc: 'Ties are supercharged! A matching choice converts into an automatic Player Victory!'
        };
      case MODIFIERS.HEAVY_OBSIDIAN:
        return {
          icon: '🪨',
          title: 'Heavy Obsidian',
          desc: 'Rock cannot be wrapped! Rock beats Scissors AND ties with Paper!'
        };
      case MODIFIERS.BANNED_PAPER:
        return {
          icon: '🚫',
          title: 'Banned Element: Paper',
          desc: 'Paper is forbidden by the cosmos this round! Playing it results in an instant forfeit!'
        };
      case MODIFIERS.DOUBLE_STAKES:
        return {
          icon: '⚡',
          title: 'Double Stakes',
          desc: 'Cosmic surge: The winner of this round scores 2 points instead of 1!'
        };
      default:
        return { icon: '🔮', title: 'Classic Field', desc: 'Standard triad rules in effect.' };
    }
  }

  /**
   * Update Level 3 Pattern Telemetry Bar
   */
  updatePatternTelemetry(level, auraHistory, stepIndex) {
    const bar = document.getElementById('pattern-intel-bar');
    const tape = document.getElementById('history-tape');
    const hint = document.getElementById('telemetry-hint');
    if (!bar || !tape || !hint) return;

    if (level === 3) {
      bar.style.display = 'flex';
      tape.innerHTML = '';

      if (auraHistory.length === 0) {
        tape.innerHTML = `<span class="history-pill">History starts after Round 1</span>`;
      } else {
        const lastFew = auraHistory.slice(-4);
        lastFew.forEach((move, i) => {
          const icon = move === CHOICES.ROCK ? '🪨 Rock' : move === CHOICES.PAPER ? '📄 Paper' : '✂️ Scissors';
          const pill = document.createElement('span');
          pill.className = 'history-pill';
          pill.textContent = `R${auraHistory.length - lastFew.length + i + 1}: ${icon}`;
          tape.appendChild(pill);
        });
      }

      hint.innerHTML = `<strong>Oracle Scanner Telemetry:</strong> Aura strictly cycles clockwise: 🪨 Rock ➔ 📄 Paper ➔ ✂️ Scissors ➔ 🪨 Rock... Predict the next link in the chain!`;
    } else {
      bar.style.display = 'none';
    }
  }

  /**
   * Update Level 4 Tactical Powers Dock
   */
  updateTacticalDock(level, powersState, onSelectPower) {
    const dock = document.getElementById('tactical-power-dock');
    const list = document.getElementById('power-cards-list');
    if (!dock || !list) return;

    if (level === 4) {
      dock.style.display = 'flex';
      list.innerHTML = '';

      powersState.forEach(p => {
        const btn = document.createElement('button');
        btn.className = `power-card-btn ${p.selected ? 'selected' : ''}`;
        btn.disabled = p.count <= 0;
        btn.innerHTML = `
          <div class="power-card-name">${p.name} <span class="power-badge-count">${p.count} left</span></div>
          <div class="power-card-desc">${p.desc}</div>
        `;
        btn.addEventListener('click', () => {
          sounds.playSelect();
          onSelectPower(p.id);
        });
        list.appendChild(btn);
      });
    } else {
      dock.style.display = 'none';
    }
  }

  /**
   * Display round clash animation and outcome banner
   */
  showClash(playerChoice, auraChoice, resultObj, onFinished) {
    const playerCard = document.getElementById('player-fighter-card');
    const auraCard = document.getElementById('aura-fighter-card');
    const outcomeBanner = document.getElementById('outcome-banner');
    const headlineEl = document.getElementById('outcome-headline');
    const expEl = document.getElementById('outcome-explanation');

    if (!playerCard || !auraCard || !outcomeBanner) return;

    // Set icons
    playerCard.innerHTML = ICONS[playerChoice] || playerChoice;
    auraCard.innerHTML = ICONS[auraChoice] || auraChoice;

    playerCard.className = 'fighter-card active-choice';
    auraCard.className = 'fighter-card opponent-active';

    // Banner styling
    outcomeBanner.className = `outcome-banner ${resultObj.outcome}`;
    outcomeBanner.style.display = 'flex';

    if (resultObj.outcome === OUTCOMES.WIN) {
      headlineEl.textContent = '🎉 Round Victory!';
    } else if (resultObj.outcome === OUTCOMES.LOSE) {
      headlineEl.textContent = '💔 Aura Took The Point!';
    } else {
      headlineEl.textContent = '🤝 Peaceful Tie!';
    }

    expEl.textContent = resultObj.reason;

    // Callback after animation completes
    setTimeout(() => {
      if (onFinished) onFinished();
    }, 800);
  }

  resetClashDisplay() {
    const playerCard = document.getElementById('player-fighter-card');
    const auraCard = document.getElementById('aura-fighter-card');
    const outcomeBanner = document.getElementById('outcome-banner');

    if (playerCard) {
      playerCard.className = 'fighter-card';
      playerCard.innerHTML = '❓';
    }
    if (auraCard) {
      auraCard.className = 'fighter-card';
      auraCard.innerHTML = '❓';
    }
    if (outcomeBanner) {
      outcomeBanner.style.display = 'none';
    }
  }

  showLevelCompleteModal(level, stars, score, onNext, onSelectMap) {
    const modal = document.getElementById('modal-level-complete');
    if (!modal) return;

    sounds.playLevelComplete();
    this.confetti.burst(80);

    const titleEl = document.getElementById('complete-level-title');
    const starsRow = document.getElementById('complete-stars-row');
    const scoreVal = document.getElementById('complete-stat-score');
    const badgeVal = document.getElementById('complete-stat-badge');
    const nextBtn = document.getElementById('btn-next-level');
    const mapBtn = document.getElementById('btn-complete-map');

    if (titleEl) titleEl.textContent = `Level 0${level} Cleared!`;

    if (starsRow) {
      let starsHtml = '';
      for (let s = 1; s <= 3; s++) {
        starsHtml += `<span class="${s <= stars ? 'star-filled' : ''}">★</span>`;
      }
      starsRow.innerHTML = starsHtml;
    }

    if (scoreVal) scoreVal.textContent = `${score} pts`;
    if (badgeVal) {
      const cfg = LEVELS_CONFIG.find(c => c.level === level);
      badgeVal.textContent = cfg ? cfg.badge : 'Victor';
    }

    if (nextBtn) {
      if (level >= 4) {
        nextBtn.textContent = 'Celebrate Grand Victory 👑';
      } else {
        nextBtn.textContent = 'Advance to Next Level ➔';
      }
      nextBtn.onclick = () => {
        sounds.playSelect();
        modal.classList.remove('active');
        onNext();
      };
    }

    if (mapBtn) {
      mapBtn.onclick = () => {
        sounds.playSelect();
        modal.classList.remove('active');
        onSelectMap();
      };
    }

    modal.classList.add('active');
  }

  showLevelFailedModal(level, pScore, aScore, onRetry, onSelectMap) {
    const modal = document.getElementById('modal-level-failed');
    if (!modal) return;

    sounds.playLose();

    const titleEl = document.getElementById('failed-level-title');
    const scoreVal = document.getElementById('failed-stat-score');
    const retryBtn = document.getElementById('btn-retry-level');
    const mapBtn = document.getElementById('btn-failed-map');

    if (titleEl) titleEl.textContent = `Level 0${level} Unfinished`;
    if (scoreVal) scoreVal.textContent = `Score: You ${pScore} - ${aScore} Aura`;

    if (retryBtn) {
      retryBtn.onclick = () => {
        sounds.playSelect();
        modal.classList.remove('active');
        onRetry();
      };
    }

    if (mapBtn) {
      mapBtn.onclick = () => {
        sounds.playSelect();
        modal.classList.remove('active');
        onSelectMap();
      };
    }

    modal.classList.add('active');
  }

  showFinalVictoryModal(totalScore, onPlayAgain, onSelectMap) {
    const modal = document.getElementById('modal-final-victory');
    if (!modal) return;

    sounds.playGrandVictory();
    this.confetti.burst(120);

    const scoreVal = document.getElementById('final-total-score');
    const streakVal = document.getElementById('final-max-streak');
    const againBtn = document.getElementById('btn-final-play-again');
    const mapBtn = document.getElementById('btn-final-map');

    if (scoreVal) scoreVal.textContent = `${totalScore} pts`;
    if (streakVal) streakVal.textContent = `${storage.state.highestStreak} Streak`;

    if (againBtn) {
      againBtn.onclick = () => {
        sounds.playSelect();
        modal.classList.remove('active');
        onPlayAgain();
      };
    }

    if (mapBtn) {
      mapBtn.onclick = () => {
        sounds.playSelect();
        modal.classList.remove('active');
        onSelectMap();
      };
    }

    modal.classList.add('active');
  }
}
