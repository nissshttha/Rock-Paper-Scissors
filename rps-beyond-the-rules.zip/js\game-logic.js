/**
 * Rock Paper Scissors — Beyond The Rules
 * Core Game Logic & Deterministic Rule Engine
 */

export const CHOICES = Object.freeze({
  ROCK: 'rock',
  PAPER: 'paper',
  SCISSORS: 'scissors'
});

export const OUTCOMES = Object.freeze({
  WIN: 'win',
  LOSE: 'lose',
  TIE: 'tie'
});

export const MODIFIERS = Object.freeze({
  NONE: 'none',
  INVERSION: 'inversion',           // Paper beats Scissors, Scissors beats Rock, Rock beats Paper
  GOLDEN_SPARK: 'golden_spark',     // Ties count as automatic Player Wins
  HEAVY_OBSIDIAN: 'heavy_obsidian', // Rock beats Scissors AND ties with Paper (Rock cannot lose)
  BANNED_PAPER: 'banned_paper',     // Paper is forbidden this round; picking it is an auto-loss
  BANNED_SCISSORS: 'banned_scissors',// Scissors is forbidden this round; picking it is an auto-loss
  DOUBLE_STAKES: 'double_stakes'    // Round winner gets 2 points instead of 1
});

export const POWERS = Object.freeze({
  NONE: 'none',
  AEGIS_SHIELD: 'aegis_shield',     // Absorbs a loss and converts it into a tie
  RULE_INVERTER: 'rule_inverter',   // Inverts round outcome (loss becomes win!)
  CRITICAL_SURGE: 'critical_surge'  // Double points if player wins
});

/**
 * Standard RPS win matrix:
 * returns OUTCOMES from the perspective of playerChoice vs opponentChoice
 */
export function getStandardOutcome(playerChoice, opponentChoice) {
  if (playerChoice === opponentChoice) {
    return OUTCOMES.TIE;
  }
  if (
    (playerChoice === CHOICES.ROCK && opponentChoice === CHOICES.SCISSORS) ||
    (playerChoice === CHOICES.SCISSORS && opponentChoice === CHOICES.PAPER) ||
    (playerChoice === CHOICES.PAPER && opponentChoice === CHOICES.ROCK)
  ) {
    return OUTCOMES.WIN;
  }
  return OUTCOMES.LOSE;
}

/**
 * Standard explanation message for classic clashes
 */
export function getStandardReason(playerChoice, opponentChoice, outcome) {
  if (outcome === OUTCOMES.TIE) {
    const name = playerChoice.charAt(0).toUpperCase() + playerChoice.slice(1);
    return `Both chose ${name} — It's a peaceful tie!`;
  }
  if (
    (playerChoice === CHOICES.ROCK && opponentChoice === CHOICES.SCISSORS) ||
    (opponentChoice === CHOICES.ROCK && playerChoice === CHOICES.SCISSORS)
  ) {
    return 'Rock crushes Scissors!';
  }
  if (
    (playerChoice === CHOICES.SCISSORS && opponentChoice === CHOICES.PAPER) ||
    (opponentChoice === CHOICES.SCISSORS && playerChoice === CHOICES.PAPER)
  ) {
    return 'Scissors cuts Paper!';
  }
  if (
    (playerChoice === CHOICES.PAPER && opponentChoice === CHOICES.ROCK) ||
    (opponentChoice === CHOICES.PAPER && playerChoice === CHOICES.ROCK)
  ) {
    return 'Paper covers Rock!';
  }
  return 'The elements clash!';
}

/**
 * Full deterministic outcome resolver handling all level modifiers & tactical powers.
 *
 * @param {string} playerChoice - 'rock' | 'paper' | 'scissors'
 * @param {string} opponentChoice - 'rock' | 'paper' | 'scissors'
 * @param {string} modifier - MODIFIERS enum
 * @param {string} power - POWERS enum
 * @returns {object} { outcome, reason, playerPoints, opponentPoints, modifierApplied, powerApplied }
 */
export function resolveRound(
  playerChoice,
  opponentChoice,
  modifier = MODIFIERS.NONE,
  power = POWERS.NONE
) {
  // Validate choices
  const validChoices = Object.values(CHOICES);
  if (!validChoices.includes(playerChoice) || !validChoices.includes(opponentChoice)) {
    throw new Error(`Invalid choices: player=${playerChoice}, opponent=${opponentChoice}`);
  }

  let outcome = OUTCOMES.TIE;
  let reason = '';
  let modifierApplied = null;
  let powerApplied = null;
  let pointMultiplier = 1;

  // 1. Check for Banned Element Modifiers
  if (modifier === MODIFIERS.BANNED_PAPER && playerChoice === CHOICES.PAPER) {
    outcome = OUTCOMES.LOSE;
    reason = 'Banned Element! Paper was forbidden this round — Auto-loss!';
    modifierApplied = 'Banned Element Violation';
  } else if (modifier === MODIFIERS.BANNED_PAPER && opponentChoice === CHOICES.PAPER) {
    outcome = OUTCOMES.WIN;
    reason = 'Opponent played the Banned Element (Paper) — Automatic Victory!';
    modifierApplied = 'Banned Element Violation';
  } else if (modifier === MODIFIERS.BANNED_SCISSORS && playerChoice === CHOICES.SCISSORS) {
    outcome = OUTCOMES.LOSE;
    reason = 'Banned Element! Scissors was forbidden this round — Auto-loss!';
    modifierApplied = 'Banned Element Violation';
  } else if (modifier === MODIFIERS.BANNED_SCISSORS && opponentChoice === CHOICES.SCISSORS) {
    outcome = OUTCOMES.WIN;
    reason = 'Opponent played the Banned Element (Scissors) — Automatic Victory!';
    modifierApplied = 'Banned Element Violation';
  } else if (modifier === MODIFIERS.HEAVY_OBSIDIAN) {
    // Heavy Obsidian: Rock is unyielding.
    // Rock vs Scissors -> Rock wins
    // Rock vs Paper -> Rock ties (Paper cannot cover heavy obsidian rock!)
    // Scissors vs Paper -> Scissors wins
    // Paper vs Scissors -> Scissors wins
    // Identical -> Tie
    if (playerChoice === opponentChoice) {
      outcome = OUTCOMES.TIE;
      reason = `Heavy Obsidian: Identical choices tie!`;
    } else if (playerChoice === CHOICES.ROCK && opponentChoice === CHOICES.PAPER) {
      outcome = OUTCOMES.TIE;
      reason = 'Heavy Obsidian: Rock resists Paper and forces a Tie!';
      modifierApplied = 'Heavy Obsidian Resisted Paper';
    } else if (opponentChoice === CHOICES.ROCK && playerChoice === CHOICES.PAPER) {
      outcome = OUTCOMES.TIE;
      reason = 'Heavy Obsidian: Rock resisted your Paper — resulting in a Tie!';
      modifierApplied = 'Heavy Obsidian Resisted Paper';
    } else {
      outcome = getStandardOutcome(playerChoice, opponentChoice);
      reason = `Heavy Obsidian: ${getStandardReason(playerChoice, opponentChoice, outcome)}`;
    }
  } else if (modifier === MODIFIERS.INVERSION) {
    // Inversion Eclipse: Exactly inverts standard win/loss conditions
    if (playerChoice === opponentChoice) {
      outcome = OUTCOMES.TIE;
      reason = `Cosmic Inversion: Identical choices still tie!`;
    } else {
      const standard = getStandardOutcome(playerChoice, opponentChoice);
      if (standard === OUTCOMES.WIN) {
        outcome = OUTCOMES.LOSE;
        reason = `Cosmic Inversion! Rules reversed: ${opponentChoice.toUpperCase()} triumphs over ${playerChoice.toUpperCase()}!`;
      } else {
        outcome = OUTCOMES.WIN;
        reason = `Cosmic Inversion! Rules reversed: ${playerChoice.toUpperCase()} triumphs over ${opponentChoice.toUpperCase()}!`;
      }
      modifierApplied = 'Cosmic Inversion Active';
    }
  } else {
    // Standard outcome
    outcome = getStandardOutcome(playerChoice, opponentChoice);
    reason = getStandardReason(playerChoice, opponentChoice, outcome);
  }

  // 2. Check for Golden Spark Modifier (Ties convert to player win)
  if (modifier === MODIFIERS.GOLDEN_SPARK && outcome === OUTCOMES.TIE) {
    outcome = OUTCOMES.WIN;
    reason = 'Golden Spark: Tied round converted into a Player Victory!';
    modifierApplied = 'Golden Spark Tie Conversion';
  }

  // 3. Check for Double Stakes Modifier
  if (modifier === MODIFIERS.DOUBLE_STAKES) {
    pointMultiplier = 2;
    modifierApplied = 'Double Stakes Active (x2 Points)';
  }

  // 4. Apply Player Tactical Powers (if any)
  if (power === POWERS.AEGIS_SHIELD && outcome === OUTCOMES.LOSE) {
    outcome = OUTCOMES.TIE;
    reason = `${reason} (Aegis Shield absorbed the defeat into a Tie!)`;
    powerApplied = 'Aegis Shield Absorbed Defeat';
  } else if (power === POWERS.RULE_INVERTER) {
    if (outcome === OUTCOMES.LOSE) {
      outcome = OUTCOMES.WIN;
      reason = `${reason} (Rule Inverter twisted defeat into Victory!)`;
      powerApplied = 'Rule Inverter Turned Defeat to Victory';
    } else if (outcome === OUTCOMES.WIN) {
      reason = `${reason} (Rule Inverter was spent!)`;
      powerApplied = 'Rule Inverter Spent';
    }
  } else if (power === POWERS.CRITICAL_SURGE) {
    if (outcome === OUTCOMES.WIN) {
      pointMultiplier *= 2;
      reason = `${reason} (Critical Surge applied! Bonus points awarded!)`;
      powerApplied = 'Critical Surge Double Score';
    }
  }

  // 5. Calculate Points
  let playerPoints = 0;
  let opponentPoints = 0;

  if (outcome === OUTCOMES.WIN) {
    playerPoints = 1 * pointMultiplier;
  } else if (outcome === OUTCOMES.LOSE) {
    opponentPoints = 1 * pointMultiplier;
  }

  return {
    outcome,
    reason,
    playerPoints,
    opponentPoints,
    modifierApplied,
    powerApplied,
    playerChoice,
    opponentChoice
  };
}

/**
 * Level Objectives & Descriptions definition
 */
export const LEVELS_CONFIG = [
  {
    level: 1,
    id: 'classic',
    title: 'Level 1: The Classic Grounds',
    subtitle: 'Master the Foundation',
    badge: 'Foundation',
    colorTheme: 'powder-blue',
    targetWins: 3,
    maxRounds: 7,
    description: 'Learn the sacred fundamentals. Classic rules apply with direct outcome explanations.',
    ruleExplanation: 'Classic Rules: Rock beats Scissors, Scissors cuts Paper, Paper wraps Rock. Matching choices tie. First to 3 wins takes the stage!',
    activeModifier: MODIFIERS.NONE,
    hasPatternIntel: false,
    hasTacticalPowers: false
  },
  {
    level: 2,
    id: 'shifted_cosmos',
    title: 'Level 2: The Shifted Cosmos',
    subtitle: 'Expect the Unexpected',
    badge: 'Cosmic Bender',
    colorTheme: 'soft-lilac',
    targetWins: 3,
    maxRounds: 7,
    description: 'Cosmic anomalies shift the battlefield! Every round activates a deterministic modifier.',
    ruleExplanation: 'Watch the Cosmic Modifier banner before making your move! Deterministic rule shifts alter how choices clash.',
    activeModifier: 'dynamic', // Selected deterministically per round
    hasPatternIntel: false,
    hasTacticalPowers: false,
    availableModifiers: [
      MODIFIERS.INVERSION,
      MODIFIERS.GOLDEN_SPARK,
      MODIFIERS.HEAVY_OBSIDIAN,
      MODIFIERS.DOUBLE_STAKES,
      MODIFIERS.BANNED_PAPER
    ]
  },
  {
    level: 3,
    id: 'oracles_echo',
    title: 'Level 3: The Oracle’s Echo',
    subtitle: 'Strategic Observation',
    badge: 'Mind Reader',
    colorTheme: 'pale-mint',
    targetWins: 3,
    maxRounds: 7,
    description: 'Aura reveals strategic telemetry. Analyze past choices to predict upcoming patterns.',
    ruleExplanation: 'Observe the Opponent Move History and the Telemetry Scanner hint. Predict Aura’s deterministic sequence to claim victory!',
    activeModifier: MODIFIERS.NONE,
    hasPatternIntel: true,
    hasTacticalPowers: false
  },
  {
    level: 4,
    id: 'beyond_rules',
    title: 'Level 4: Beyond The Rules',
    subtitle: 'The Grand Quantum Duel',
    badge: 'Grand Master',
    colorTheme: 'lavender',
    targetWins: 4,
    maxRounds: 9,
    description: 'The ultimate showdown! Deploy limited-use Tactical Power Cards to outwit the Grand Pastel Master.',
    ruleExplanation: 'Combine classic RPS with 3 Tactical Energy Cards (Aegis Shield, Rule Inverter, Critical Surge). First to 4 wins is crowned Grand Champion!',
    activeModifier: MODIFIERS.NONE,
    hasPatternIntel: false,
    hasTacticalPowers: true,
    powersAvailable: [
      { id: POWERS.AEGIS_SHIELD, name: 'Aegis Shield', count: 1, desc: 'Converts a round defeat into a safe Tie' },
      { id: POWERS.RULE_INVERTER, name: 'Rule Inverter', count: 1, desc: 'Inverts round outcome — turn defeat into victory' },
      { id: POWERS.CRITICAL_SURGE, name: 'Critical Surge', count: 1, desc: 'Awards 2 points if you win this round' }
    ]
  }
];
