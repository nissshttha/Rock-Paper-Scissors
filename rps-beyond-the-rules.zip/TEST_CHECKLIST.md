# Manual & Automated Testing Checklist (TEST_CHECKLIST.md)

Use this checklist to verify the game functionality across devices and browsers during hackathon evaluation.

---

## 1. Automated Test Suites

### A. Core Engine Unit Tests (Node CLI)
- **Command**: `agy-node tests/unit-tests.js` (or `npm test`)
- **Expected Result**: 46 assertions passing, 0 failed.
- **Coverage**:
  - Classic winning combinations (Rock > Scissors, Scissors > Paper, Paper > Rock)
  - Classic losing combinations
  - Classic tie combinations
  - Points awarding and multiplier verification
  - Cosmic Inversion modifier (all combinations inverted)
  - Golden Spark modifier (tie conversion to victory)
  - Heavy Obsidian modifier (Rock resists Paper to force tie)
  - Banned Element auto-forfeiture
  - Tactical Powers: Aegis Shield, Rule Inverter, Critical Surge
  - Level configuration integrity

### B. Full Gameplay End-to-End Simulation (Node CLI)
- **Command**: `agy-node tests/gameplay-simulation.js`
- **Expected Result**: Simulates a complete playthrough through all 4 levels, verifies score thresholds, star calculations, achievement unlocks, and persistence.

### C. Visual In-Browser Test Runner
- **URL**: `http://localhost:3000/tests/unit-tests.html`
- **Expected Result**: Visual green checkmarks for all rule tests with summary box displayed.

---

## 2. Manual Gameplay Checklist

### Welcome Screen & Navigation
- [ ] Title, subtitle, and animated Aura mascot render cleanly.
- [ ] "Start Journey" button navigates directly to Level 1.
- [ ] "Realm Map" button opens the level selection screen.
- [ ] "How To Play" button opens the multi-tab rules guide modal.
- [ ] Top navigation bar buttons (Sound, Map, Rules, Settings) function from any screen.

### Level 1: The Classic Grounds
- [ ] Level title "Level 01: Master the Foundation" and objective ("First to 3 Wins") display in HUD.
- [ ] Clicking Rock, Paper, or Scissors initiates the clash animation.
- [ ] Clashes clearly show player choice vs Aura choice with colored outcome banners.
- [ ] Ties display explanation: "Both chose [Element] — It's a peaceful tie!" (no points awarded).
- [ ] Reaching 3 wins unlocks the Level Cleared modal with 1–3 star rating and score summary.
- [ ] Advancing moves to Level 2 and unlocks Level 2 on the Realm Map.

### Level 2: The Shifted Cosmos
- [ ] The Cosmic Modifier banner prominently displays the active rule *before* each round.
- [ ] **Inversion Round**: Playing Paper against Scissors wins; outcome banner explains the rule inversion.
- [ ] **Golden Spark Round**: Matching choices award an automatic win to the player.
- [ ] **Heavy Obsidian Round**: Rock clashes with Paper and forces a tie instead of a defeat.
- [ ] Advancing moves to Level 3 and unlocks Level 3 on the Realm Map.

### Level 3: The Oracle’s Echo
- [ ] Aura's Move History Tape updates with each round, displaying Aura's previous moves.
- [ ] Oracle Scanner Telemetry card hints that Aura rotates clockwise: `Rock ➔ Paper ➔ Scissors ➔ Rock`.
- [ ] Predicting Aura's move based on the history tape and counter-playing consistently secures points.
- [ ] Advancing moves to Level 4.

### Level 4: Beyond The Rules (Grand Showdown)
- [ ] Tactical Power Cards dock appears with 3 power cards:
  - **Aegis Shield** (1 charge)
  - **Rule Inverter** (1 charge)
  - **Critical Surge** (1 charge)
- [ ] Clicking a power card highlights it before making a move.
- [ ] Activating Aegis Shield on a losing clash converts the loss into a tie.
- [ ] Activating Rule Inverter on a losing clash converts it into a win.
- [ ] Activating Critical Surge on a winning clash awards +2 points.
- [ ] Power card charge decrements upon use (`0 left`) and is disabled.
- [ ] Reaching 4 wins triggers the **Grand Champion Finale Modal** with golden crown and confetti burst!

### Failure & Retry States
- [ ] If Aura reaches the target score before the player, the "Realm Unfinished" modal appears.
- [ ] Clicking "Try Again" restarts the level smoothly without losing overall progress.

### Audio & Sound Control
- [ ] Sound effects (bubble pops, whooshes, chimes, victory fanfares) play upon interaction.
- [ ] Clicking the sound toggle icon (🔊 / 🔇) mutes all audio immediately.
- [ ] Muted preference persists upon page refresh.

### Keyboard Shortcuts
- [ ] Pressing `[R]` or `[1]` chooses Rock.
- [ ] Pressing `[P]` or `[2]` chooses Paper.
- [ ] Pressing `[S]` or `[3]` chooses Scissors.
- [ ] Pressing `[Esc]` closes open modals or menus.
- [ ] Input is locked during clash resolution so rapid keypresses do not double-score.

### Settings & Progress Reset
- [ ] Opening Settings modal allows toggling Sound and Reduced Motion.
- [ ] Clicking "Reset All Saved Progress" prompts for confirmation before safely resetting unlocked levels.

### Responsive Design
- [ ] Desktop layout (> 1024px): Balanced centered layout with spacious cards.
- [ ] Tablet layout (768px - 1024px): Compact cards and flexible HUD.
- [ ] Mobile layout (< 768px): Choice buttons remain large and easy to tap, no horizontal scroll, text remains crisp and readable.
