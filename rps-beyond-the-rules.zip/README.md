# Rock Paper Scissors — Beyond The Rules ✂️🪨📄✨

> **A modern, creative pastel reimagining of the classic Rock Paper Scissors game with 4 progressive realms, cosmic rule modifiers, pattern deduction, tactical energy cards, and an expressive opponent.**

Built with zero-dependency modern HTML5, CSS3, and ES6 JavaScript, crafted faithfully after the Stitch prototype art direction.

---

## 🌟 Quick Links & Live Demonstration

- **Local Development Server**: `http://localhost:3000`
- **Interactive Unit Test Suite**: `http://localhost:3000/tests/unit-tests.html`
- **Zero-Build Requirement**: Directly open `index.html` in any modern web browser or run `npm start` / `agy-node server.js`.

---

## 🎮 Concept: "Beyond The Rules"

Classic Rock Paper Scissors is intuitive, but repetitive clicking can get boring quickly. **Beyond The Rules** keeps the familiar foundation intact while progressively introducing mechanics that demand observation, quick adaptation, and high-stakes tactical choices:

> *"I already know how to play this game, but I didn’t expect THIS."*

### 🌌 The 4 Playable Realms

| Level | Realm Name | Core Gameplay Challenge | Objective | Opponent Dynamics |
|---|---|---|---|---|
| **Level 1** | **The Classic Grounds** | Pure fundamentals: Rock beats Scissors, Scissors beats Paper, Paper beats Rock. Clear feedback explaining clash results and tie handling. | First to 3 Wins | Aura introduces the basics with gentle, supportive commentary. |
| **Level 2** | **The Shifted Cosmos** | Dynamic deterministic round modifiers appear each round: **Cosmic Inversion** (reversed win/loss), **Golden Spark** (ties become player wins), **Heavy Obsidian** (Rock cannot be beaten by Paper), **Banned Element** (forbidden move), and **Double Stakes** (x2 points). | First to 3 Wins | Aura respects cosmic shifts, adapting their strategy to the active anomaly. |
| **Level 3** | **The Oracle’s Echo** | True strategy and pattern deduction. Aura's move history is recorded on a visible tape, while the Oracle Scanner telemetry reveals Aura's clockwise cycle: `Rock ➔ Paper ➔ Scissors ➔ Rock`. | First to 3 Wins | 100% deterministic, transparent cycle. Observation guarantees mastery. |
| **Level 4** | **Beyond The Rules** | High-stakes Grand Finale against Grand Master Aura. The player gains access to 3 limited-use Tactical Energy Cards: **Aegis Shield** (negates loss into tie), **Rule Inverter** (twists defeat into victory), and **Critical Surge** (+2 points on win). | First to 4 Wins | Aura unleashes dual-phase counter-tendencies, pushing your tactical foresight to the limit. |

---

## 🎨 Visual Identity & Art Direction

Faithfully modeled from the Stitch prototype design specifications:
- **Pastel Color Palette**:
  - **Lavender**: `#E4DCF9` (hero cards & Level 4 accents)
  - **Soft Lilac**: `#F4E7FA` (tactical card docks & badges)
  - **Powder Blue**: `#D6ECFB` (player choice cards & Level 1 accents)
  - **Pale Mint**: `#D6F6E4` (victory states & Level 3 telemetry)
  - **Butter Yellow**: `#FEF4BD` (primary action buttons & modifier alerts)
  - **Warm Cream**: `#FAF8F3` (delicate paper card surfaces)
  - **Muted Peach**: `#FDE5D8` (opponent cards & alert accents)
  - **Deep Navy**: `#151D33` (crisp, readable typography, tactile borders, and 4px drop-shadows)
- **Aesthetic**: Neo-pastel indie game charm with tactile rounded pill cards, 2.5px crisp borders, subtle offset drop shadows (`0 5px 0 var(--c-navy-dark)`), and smooth micro-interactions.
- **Expressive Opponent**: Animated "Aura" celestial mascot SVG with expressive moods: *idle*, *thinking*, *happy*, *puzzled*, *tie*, *celebrating*, and *defeated*.
- **Celebration Effects**: Soft pastel particle confetti engine rendered smoothly on a transparent HTML5 canvas.

---

## ⌨️ Controls & Accessibility

- **Mouse / Touch**: Tap or click any of the 3 choice cards or tactical cards.
- **Keyboard Shortcuts**:
  - `[R]` or `[1]` : Select **Rock**
  - `[P]` or `[2]` : Select **Paper**
  - `[S]` or `[3]` : Select **Scissors**
  - `[Esc]` : Close open modals or menus
- **Accessibility Features**:
  - Visible focus rings for keyboard tab navigation.
  - High contrast text (`#151D33` Deep Navy on pastel backgrounds).
  - Screen reader friendly with semantic ARIA roles (`role="region"`, `role="status"`, `aria-live="polite"`).
  - **Reduced Motion Support**: Automatic detection via `@media (prefers-reduced-motion: reduce)` plus manual toggle in Settings.
  - **Web Audio Sound Synthesizer**: Pure Web Audio API synthesized soft chimes with instant Mute/Unmute toggle. No loud unexpected audio.

---

## 💾 Progression & State Persistence

Progress is automatically saved to `localStorage`:
- Unlocked levels (`[1, 2, 3, 4]`)
- Star ratings earned per level (1–3 stars based on streak and rounds taken)
- High scores recorded per level
- Highest winning streak
- Badges & Achievements (e.g. *First Step*, *Cosmic Bender*, *Mind Reader*, *Grand Champion*)
- Sound and motion preferences
- Dedicated **Reset Progress** option in Settings with user confirmation dialog.

---

## 🚀 How to Run Locally

### Option A: Using the Built-In Node Server
```bash
# In the project directory:
agy-node server.js
# Or if standard node is installed:
npm start
```
Open your browser to: `http://localhost:3000`

### Option B: Direct Browser Launch
Open `index.html` directly in Google Chrome, Microsoft Edge, Mozilla Firefox, or Apple Safari.

---

## 🧪 Testing & Verification

Automated test suites are included in `tests/`:

1. **Unit Tests (Core Logic & Rule Matrix)**:
   ```bash
   agy-node tests/unit-tests.js
   ```
   *46 automated assertions verifying standard RPS, all Level 2 modifiers, Level 3 telemetry, and Level 4 powers with 100% pass rate.*

2. **Full Gameplay Simulation**:
   ```bash
   agy-node tests/gameplay-simulation.js
   ```
   *Simulates complete player journey through all 4 levels, objective validation, and victory state.*

3. **In-Browser Test Runner**:
   Open `tests/unit-tests.html` in your browser.

---

## 📁 Project File Architecture

```
rps-beyond-the-rules/
├── index.html               # Main semantic HTML structure, HUD & modal overlays
├── server.js                # Zero-dependency local development HTTP server
├── package.json             # NPM metadata and script shortcuts
├── README.md                # Project documentation and guide
├── AI_LOG.md                # Transparent AI development log & decision record
├── TEST_CHECKLIST.md        # Comprehensive manual testing checklist
├── css/
│   └── style.css            # Pastel design system, variables, animations & layout
├── js/
│   ├── game-logic.js        # Pure deterministic rule engine & clash resolver
│   ├── opponent-ai.js       # Aura character logic, behavioral cycles & dialogue
│   ├── audio.js             # Web Audio API subtle chime sound synthesizer
│   ├── storage.js           # LocalStorage persistence, achievements & settings
│   ├── ui.js                # UI DOM controller, SVG graphics & confetti engine
│   └── app.js               # Main game coordinator, input locks & keyboard bindings
└── tests/
    ├── unit-tests.js        # Automated unit test assertions (Node executable)
    ├── unit-tests.html      # Visual in-browser unit test runner
    └── gameplay-simulation.js# Complete 4-level end-to-end player simulation
```
