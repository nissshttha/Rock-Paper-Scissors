/**
 * Rock Paper Scissors — Beyond The Rules
 * Opponent Character: Aura the Cosmic Guide & Sage
 * Deterministic AI logic, Expressive Dialogue & Behavioral Patterns
 */

import { CHOICES, MODIFIERS } from './game-logic.js';

export const AURA_MOODS = Object.freeze({
  IDLE: 'idle',
  THINKING: 'thinking',
  HAPPY: 'happy',
  PUZZLED: 'puzzled',
  TIE: 'tie',
  CELEBRATING: 'celebrating',
  DEFEATED: 'defeated',
  SHOCKED: 'shocked'
});

export class OpponentAI {
  constructor() {
    this.name = 'Aura';
    this.history = []; // Array of CHOICES played by Aura
    this.playerHistory = []; // Array of CHOICES played by Player
    this.mood = AURA_MOODS.IDLE;
    this.level3StepIndex = 0; // Fixed index for Level 3 cycle
    this.level3Pattern = [CHOICES.ROCK, CHOICES.PAPER, CHOICES.SCISSORS];
  }

  reset(level = 1) {
    this.history = [];
    this.playerHistory = [];
    this.mood = AURA_MOODS.IDLE;
    this.level3StepIndex = Math.floor(Math.random() * 3); // Start anywhere in the cycle, then advance deterministically
  }

  recordRound(auraChoice, playerChoice) {
    this.history.push(auraChoice);
    this.playerHistory.push(playerChoice);
  }

  /**
   * Generates Aura's choice based on the active level and rules.
   *
   * @param {number} level - Current level (1 - 4)
   * @param {string} modifier - Active modifier from MODIFIERS enum
   * @returns {string} One of CHOICES.ROCK, CHOICES.PAPER, CHOICES.SCISSORS
   */
  decideMove(level, modifier = MODIFIERS.NONE) {
    const allChoices = [CHOICES.ROCK, CHOICES.PAPER, CHOICES.SCISSORS];

    // LEVEL 1: Balanced & Fair Classic Duel
    if (level === 1) {
      // Natural human-like choice: avoids playing the exact same move 3 times in a row
      if (this.history.length >= 2) {
        const last1 = this.history[this.history.length - 1];
        const last2 = this.history[this.history.length - 2];
        if (last1 === last2) {
          const filtered = allChoices.filter(c => c !== last1);
          return filtered[Math.floor(Math.random() * filtered.length)];
        }
      }
      return allChoices[Math.floor(Math.random() * allChoices.length)];
    }

    // LEVEL 2: The Shifted Cosmos
    if (level === 2) {
      // If a move is banned, Aura NEVER plays the banned element!
      let validChoices = [...allChoices];
      if (modifier === MODIFIERS.BANNED_PAPER) {
        validChoices = validChoices.filter(c => c !== CHOICES.PAPER);
      } else if (modifier === MODIFIERS.BANNED_SCISSORS) {
        validChoices = validChoices.filter(c => c !== CHOICES.SCISSORS);
      }

      // In Inversion, Aura understands the shift and plays from valid choices
      return validChoices[Math.floor(Math.random() * validChoices.length)];
    }

    // LEVEL 3: The Oracle's Echo (Predictable, Fair, Deterministic Cycle)
    if (level === 3) {
      // Clockwise rotation: Rock -> Paper -> Scissors -> Rock -> ...
      const chosen = this.level3Pattern[this.level3StepIndex % this.level3Pattern.length];
      this.level3StepIndex++;
      return chosen;
    }

    // LEVEL 4: Beyond The Rules (Tactical Master)
    if (level === 4) {
      // Aura reacts to player's recent tendencies:
      // If player played Rock frequently, Aura leans towards Paper
      if (this.playerHistory.length >= 2) {
        const lastPlayerMove = this.playerHistory[this.playerHistory.length - 1];
        // 60% of the time, anticipate the player repeating or shifting
        const roll = Math.random();
        if (roll < 0.5) {
          // Play counter to last move
          if (lastPlayerMove === CHOICES.ROCK) return CHOICES.PAPER;
          if (lastPlayerMove === CHOICES.PAPER) return CHOICES.SCISSORS;
          if (lastPlayerMove === CHOICES.SCISSORS) return CHOICES.ROCK;
        } else if (roll < 0.75) {
          // Play matching move
          return lastPlayerMove;
        }
      }
      return allChoices[Math.floor(Math.random() * allChoices.length)];
    }

    return allChoices[Math.floor(Math.random() * allChoices.length)];
  }

  /**
   * Get contextual dialogue for Aura based on round outcome and level
   */
  getDialogue(outcome, level, modifier = MODIFIERS.NONE, power = null) {
    if (power) {
      return 'Incredible! You invoked a tactical power card!';
    }

    const dialogues = {
      levelStart: {
        1: [
          'Greetings, traveler! Let us begin with the pure harmony of the triad.',
          'Show me your instincts. Rock, Paper, or Scissors?'
        ],
        2: [
          'The cosmos is shifting! Keep your eyes on the active modifier banner.',
          'Rules are fluid here. Adapt quickly or be swept away!'
        ],
        3: [
          'Notice how I move. Every step in the cosmos has a rhythm.',
          'Check my move history and scanner telemetry. Do you see the pattern?'
        ],
        4: [
          'You have reached the pinnacle. Beyond the rules, destiny awaits!',
          'Deploy your energy cards wisely. This is our grand showdown!'
        ]
      },
      win: { // Player won the round
        1: [
          'Well read! A crisp, decisive clash.',
          'Splendid move! Your timing was immaculate.',
          'Point to you! You understand the flow.'
        ],
        2: [
          'Ah! You mastered the anomaly effortlessly!',
          'Superb adaptation to the cosmic shift!',
          'You turned the modifier in your favor!'
        ],
        3: [
          'You saw through my cycle! Exactly as the Oracle foretold.',
          'Impressive deduction! You read my history perfectly.',
          'My rhythm was decoded! Brilliant play.'
        ],
        4: [
          'A masterstroke! My defenses couldn’t hold.',
          'Astounding tactics! You earned that point.',
          'Formidable! You fight like a grand champion.'
        ]
      },
      lose: { // Opponent won the round
        1: [
          'My move found its mark! Ready for another?',
          'Point to Aura! Keep your focus sharp.',
          'A classic clash! The triad smiles upon me.'
        ],
        2: [
          'The cosmic rules favored my path this time!',
          'Always verify the active modifier before picking!',
          'A twist of fate! You can still bounce back.'
        ],
        3: [
          'Look closely at my history tape. The sequence repeats!',
          'Don’t guess randomly — consult the Telemetry hint!',
          'My cycle continues. Can you break it next round?'
        ],
        4: [
          'A decisive strike! Do you have a power card in reserve?',
          'My cosmic energy surges! What will you answer with?',
          'Hold steady! The duel is far from over.'
        ]
      },
      tie: [
        'A mirror image! Our thoughts aligned perfectly.',
        'Harmony! Neither element gave ground.',
        'A peaceful tie! The tension mounts.'
      ]
    };

    if (outcome === 'start') {
      const list = dialogues.levelStart[level] || dialogues.levelStart[1];
      return list[Math.floor(Math.random() * list.length)];
    }

    if (outcome === 'tie') {
      return dialogues.tie[Math.floor(Math.random() * dialogues.tie.length)];
    }

    const category = outcome === 'win' ? dialogues.win[level] : dialogues.lose[level];
    const fallback = outcome === 'win' ? dialogues.win[1] : dialogues.lose[1];
    const list = category || fallback;
    return list[Math.floor(Math.random() * list.length)];
  }
}
