/**
 * Complete Full Gameplay Journey Simulation Test
 * Simulates a player playing through:
 * 1. Title -> Level 1 (Classic: 3 wins)
 * 2. Level 2 (Shifted Cosmos: 3 wins with Inversion, Golden Spark, Heavy Obsidian)
 * 3. Level 3 (Oracle's Echo: 3 wins reading Pattern cycle)
 * 4. Level 4 (Beyond The Rules: 4 wins deploying Tactical Powers)
 * 5. Grand Champion Victory state & persistence check!
 */

import { CHOICES, OUTCOMES, MODIFIERS, POWERS, LEVELS_CONFIG, resolveRound } from '../js/game-logic.js';
import { OpponentAI, AURA_MOODS } from '../js/opponent-ai.js';
import { storage } from '../js/storage.js';

let stepCount = 0;
function logStep(msg) {
  stepCount++;
  console.log(`[Step ${stepCount}] ${msg}`);
}

console.log('\n======================================================');
console.log('🎮 STARTING FULL 4-LEVEL GAMEPLAY JOURNEY SIMULATION');
console.log('======================================================\n');

// Mock localStorage if in node environment without window.localStorage
if (typeof localStorage === 'undefined') {
  global.localStorage = {
    _data: {},
    getItem(k) { return this._data[k] || null; },
    setItem(k, v) { this._data[k] = String(v); },
    removeItem(k) { delete this._data[k]; },
    clear() { this._data = {}; }
  };
}

const opponent = new OpponentAI();

// -------------------------------------------------------------------------
// SIMULATION LEVEL 1: The Classic
// -------------------------------------------------------------------------
logStep('Starting LEVEL 1: The Classic Grounds');
opponent.reset(1);
let pWins = 0;
let oWins = 0;
let round = 1;

while (pWins < 3 && oWins < 3 && round <= 10) {
  const oMove = opponent.decideMove(1, MODIFIERS.NONE);
  // Player chooses counter to win
  let pMove = CHOICES.ROCK;
  if (oMove === CHOICES.ROCK) pMove = CHOICES.PAPER;
  else if (oMove === CHOICES.PAPER) pMove = CHOICES.SCISSORS;
  else if (oMove === CHOICES.SCISSORS) pMove = CHOICES.ROCK;

  const res = resolveRound(pMove, oMove, MODIFIERS.NONE);
  opponent.recordRound(oMove, pMove);
  pWins += res.playerPoints;
  oWins += res.opponentPoints;

  console.log(`  Round ${round}: Player (${pMove}) vs Aura (${oMove}) => ${res.outcome.toUpperCase()} (${res.reason})`);
  round++;
}

if (pWins >= 3) {
  console.log(`  ✓ Level 1 Cleared! (Player ${pWins} - ${oWins} Aura)`);
  storage.completeLevel(1, 3, 450);
} else {
  throw new Error('Level 1 failed to clear');
}

// -------------------------------------------------------------------------
// SIMULATION LEVEL 2: The Shifted Cosmos
// -------------------------------------------------------------------------
logStep('Starting LEVEL 2: The Shifted Cosmos');
opponent.reset(2);
pWins = 0;
oWins = 0;
round = 1;
const modifiersL2 = LEVELS_CONFIG[1].availableModifiers;

while (pWins < 3 && oWins < 3 && round <= 10) {
  const mod = modifiersL2[(round - 1) % modifiersL2.length];
  const oMove = opponent.decideMove(2, mod);

  // Player intelligently plays to win according to active modifier
  let pMove = CHOICES.ROCK;
  if (mod === MODIFIERS.INVERSION) {
    // Under inversion: Paper beats Scissors, Scissors beats Rock, Rock beats Paper
    if (oMove === CHOICES.ROCK) pMove = CHOICES.SCISSORS;
    else if (oMove === CHOICES.SCISSORS) pMove = CHOICES.PAPER;
    else if (oMove === CHOICES.PAPER) pMove = CHOICES.ROCK;
  } else if (mod === MODIFIERS.GOLDEN_SPARK) {
    // Under Golden Spark, matching ties count as win!
    pMove = oMove;
  } else if (mod === MODIFIERS.HEAVY_OBSIDIAN) {
    pMove = CHOICES.ROCK; // Rock never loses
  } else if (mod === MODIFIERS.BANNED_PAPER) {
    pMove = CHOICES.ROCK;
  } else {
    // Double stakes standard
    if (oMove === CHOICES.ROCK) pMove = CHOICES.PAPER;
    else if (oMove === CHOICES.PAPER) pMove = CHOICES.SCISSORS;
    else pMove = CHOICES.ROCK;
  }

  const res = resolveRound(pMove, oMove, mod);
  opponent.recordRound(oMove, pMove);
  pWins += res.playerPoints;
  oWins += res.opponentPoints;

  console.log(`  Round ${round} [${mod}]: Player (${pMove}) vs Aura (${oMove}) => ${res.outcome.toUpperCase()} (${res.reason})`);
  round++;
}

if (pWins >= 3) {
  console.log(`  ✓ Level 2 Cleared! (Player ${pWins} - ${oWins} Aura)`);
  storage.completeLevel(2, 3, 550);
} else {
  throw new Error('Level 2 failed to clear');
}

// -------------------------------------------------------------------------
// SIMULATION LEVEL 3: The Oracle's Echo (Pattern Deducer)
// -------------------------------------------------------------------------
logStep("Starting LEVEL 3: The Oracle's Echo");
opponent.reset(3);
pWins = 0;
oWins = 0;
round = 1;

while (pWins < 3 && oWins < 3 && round <= 10) {
  // Opponent cycles Rock -> Paper -> Scissors -> Rock
  const nextExpectedMove = opponent.level3Pattern[opponent.level3StepIndex % 3];
  const oMove = opponent.decideMove(3, MODIFIERS.NONE);

  if (oMove !== nextExpectedMove) {
    throw new Error(`Level 3 pattern violation: Expected ${nextExpectedMove}, Got ${oMove}`);
  }

  // Counter nextExpectedMove
  let pMove = CHOICES.PAPER;
  if (oMove === CHOICES.PAPER) pMove = CHOICES.SCISSORS;
  else if (oMove === CHOICES.SCISSORS) pMove = CHOICES.ROCK;

  const res = resolveRound(pMove, oMove, MODIFIERS.NONE);
  opponent.recordRound(oMove, pMove);
  pWins += res.playerPoints;
  oWins += res.opponentPoints;

  console.log(`  Round ${round} (Pattern Step): Aura played ${oMove}, Player countered with ${pMove} => ${res.outcome.toUpperCase()}`);
  round++;
}

if (pWins >= 3) {
  console.log(`  ✓ Level 3 Cleared! (Player ${pWins} - ${oWins} Aura)`);
  storage.completeLevel(3, 3, 650);
} else {
  throw new Error('Level 3 failed to clear');
}

// -------------------------------------------------------------------------
// SIMULATION LEVEL 4: Beyond The Rules (Tactical Master)
// -------------------------------------------------------------------------
logStep('Starting LEVEL 4: Beyond The Rules (Grand Showdown)');
opponent.reset(4);
pWins = 0;
oWins = 0;
round = 1;

const powers = [
  { id: POWERS.AEGIS_SHIELD, used: false },
  { id: POWERS.RULE_INVERTER, used: false },
  { id: POWERS.CRITICAL_SURGE, used: false }
];

while (pWins < 4 && oWins < 4 && round <= 10) {
  const oMove = opponent.decideMove(4, MODIFIERS.NONE);
  let power = POWERS.NONE;

  // Use powers tactically
  if (round === 1) {
    power = POWERS.CRITICAL_SURGE; // Surge for 2 points on first win
  } else if (round === 2) {
    power = POWERS.RULE_INVERTER;
  } else if (round === 3) {
    power = POWERS.AEGIS_SHIELD;
  }

  let pMove = CHOICES.ROCK;
  if (power === POWERS.RULE_INVERTER) {
    // With rule inverter, even if we lose standard, we win!
    // E.g. opponent plays Paper, we play Rock (ordinarily lose, inverter turns to win!)
    pMove = CHOICES.ROCK;
  } else {
    // Normal counter
    if (oMove === CHOICES.ROCK) pMove = CHOICES.PAPER;
    else if (oMove === CHOICES.PAPER) pMove = CHOICES.SCISSORS;
    else pMove = CHOICES.ROCK;
  }

  const res = resolveRound(pMove, oMove, MODIFIERS.NONE, power);
  opponent.recordRound(oMove, pMove);
  pWins += res.playerPoints;
  oWins += res.opponentPoints;

  console.log(`  Round ${round} [Power: ${power}]: Player (${pMove}) vs Aura (${oMove}) => ${res.outcome.toUpperCase()} (pts: +${res.playerPoints}) - ${res.reason}`);
  round++;
}

if (pWins >= 4) {
  console.log(`  ✓ Level 4 Cleared! (Player ${pWins} - ${oWins} Aura)`);
  storage.completeLevel(4, 3, 950);
  storage.unlockAchievement('grand_champion');
} else {
  throw new Error('Level 4 failed to clear');
}

// -------------------------------------------------------------------------
// VERIFY SAVE STATE & PROGRESSION COMPLETION
// -------------------------------------------------------------------------
logStep('Verifying Save State & Unlocked Levels');
console.log('  Unlocked Levels:', storage.getUnlockedLevels());
console.log('  Completed Levels:', storage.state.completedLevels);
console.log('  Stars per Level:', storage.state.levelStars);
console.log('  High Scores:', storage.state.highScores);
console.log('  Achievements:', storage.state.achievements);

if (storage.getUnlockedLevels().length < 4) {
  throw new Error('All 4 levels must be unlocked after clearing');
}
if (!storage.hasAchievement('grand_champion')) {
  throw new Error('Grand champion achievement missing');
}

console.log('\n======================================================');
console.log('✨ FULL 4-LEVEL JOURNEY SIMULATION COMPLETED WITH 100% SUCCESS!');
console.log('======================================================\n');
